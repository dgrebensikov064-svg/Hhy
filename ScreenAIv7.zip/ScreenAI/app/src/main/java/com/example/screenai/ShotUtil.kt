package com.example.screenai

import android.graphics.Bitmap
import android.media.Image
import java.io.File

object ShotUtil {
    fun fromImage(img: Image, w: Int, h: Int): Bitmap {
        val p = img.planes[0]
        val rowPad = p.rowStride - p.pixelStride * w
        val full = Bitmap.createBitmap(w + rowPad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(p.buffer)
        return Bitmap.createBitmap(full, 0, 0, w, h)
    }

    fun saveJpeg(src: Bitmap, file: File, maxSide: Int = 1280) {
        val scale = maxSide.toFloat() / maxOf(src.width, src.height)
        val bmp = if (scale < 1f) {
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        } else src
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
    }
}
